function getSortedArray() {
    var array = document.getElementById('inputValue').value.split(" ");
array.sort(function(a, b) {
  return b - a;
});

var ele = document.getElementById('result');
ele.textContent = "Sorted Array " + array;
inputValue.value = ""; 
}