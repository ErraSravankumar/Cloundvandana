function getSentence() {
    var sentence = document.getElementById("inputValue");
    var sentenceArray = sentence.value.split(" ");
    console.log(sentenceArray)
    for (var i = 0; i < sentenceArray.length; i++) {
        sentenceArray[i] = sentenceArray[i].split('').reverse().join('');
      }
      
      var reversedSentence = sentenceArray.join(' ');
      var ele = document.getElementById('result');
      ele.textContent = "Reversed Sentence: " + reversedSentence;
      inputValue.value = "";
    
}